<?php
// Configuración de la base de datos
$host = 'localhost';
$dbname = 'tienda';
$username = 'root';
$password = '';